from setuptools import setup

setup(
    name="bmi_calculator_realy",
    version="0.1",
    description="This Package Calculate Your BMI and Condition (Pip Tutorial)",
    packages = ["bmi_calculator_realy"],
    author="Tolga Isik",
    zip_safe = False
    )